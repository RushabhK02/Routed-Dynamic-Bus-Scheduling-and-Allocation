DATASET DESCRIPTION document contains a table of the different attributes and their
description
RouteAnalysis file contains a sample file of the uncleaned data