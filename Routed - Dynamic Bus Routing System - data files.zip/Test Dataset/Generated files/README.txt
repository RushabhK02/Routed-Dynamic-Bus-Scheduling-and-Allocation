Bus schedules
Format:Bus Schedule_route-no_month_date_day_method
Contains the generated schedule files for each method

Forecasted Trips
Format:Forecasted_trips_route-no_month_date_day_method
Contains the forecasted trips files for each method

Original Data(Cleaned Data)
Format:Clean data route-no_direction_year_month_date_day
Cleaned file containing the required attributes only.